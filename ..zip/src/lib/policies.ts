import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";
import type { RoundTripRule } from "@/lib/pricing/roundtrip";

export interface BookingSettings {
  meetGreetEnabled: boolean;
  /** Only set when an admin has approved the charge. Otherwise null = "to be confirmed". */
  meetGreetChargeCents: number | null;
  waitingIncludedMinutes: number;
  waitingIncrementMinutes: number;
  /** Only set when an admin has approved the rate. */
  waitingRateCents: number | null;
}

export const DEFAULT_SETTINGS: BookingSettings = { meetGreetEnabled: true, meetGreetChargeCents: null, waitingIncludedMinutes: 15, waitingIncrementMinutes: 15, waitingRateCents: null };

export async function loadBookingSettings(db: SupabaseClient): Promise<BookingSettings> {
  try {
    const { data } = await db.from("booking_settings").select("*").limit(1).maybeSingle();
    if (!data) return DEFAULT_SETTINGS;
    return {
      meetGreetEnabled: data.meet_greet_enabled !== false,
      meetGreetChargeCents: data.meet_greet_charge_approved && data.meet_greet_charge_cents != null ? Number(data.meet_greet_charge_cents) : null,
      waitingIncludedMinutes: Number(data.waiting_included_minutes ?? 15),
      waitingIncrementMinutes: Number(data.waiting_increment_minutes ?? 15) || 15,
      waitingRateCents: data.waiting_rate_approved && data.waiting_rate_cents != null ? Number(data.waiting_rate_cents) : null,
    };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export const waitingPolicyText = (included: number, step: number) =>
  `Your booking includes ${included} minutes of waiting time. Additional waiting time beyond the included ${included} minutes may incur waiting charges, calculated in ${step}-minute increments.`;

export const DEFAULT_POLICY_TEXT = {
  noShow: "If a passenger does not show up for the confirmed pickup, the full applicable trip price may be charged in accordance with the company's no-show policy. If you cannot locate your driver or need help with pickup arrangements, please contact Vanta right away.",
  assistance: "Our drivers aim to provide thoughtful, passenger-conscious service and reasonable assistance throughout your journey, including helping passengers with luggage and getting in and out of the vehicle when reasonably possible.",
  availability: "You can submit a request at any time. Availability and final confirmation depend on the location, driver or affiliate availability and applicable booking rules.",
};

export interface PublicPolicies {
  waitingText: string; noShowText: string; assistanceText: string; availabilityText: string;
  meetGreet: { enabled: boolean; chargeCents: number | null };
  roundTripDiscountActive: boolean;
}

export async function loadPublicPolicies(db: SupabaseClient | null): Promise<PublicPolicies> {
  let s = DEFAULT_SETTINGS; let noShow = DEFAULT_POLICY_TEXT.noShow, assistance = DEFAULT_POLICY_TEXT.assistance, availability = DEFAULT_POLICY_TEXT.availability;
  let rtActive = false;
  if (db) {
    s = await loadBookingSettings(db);
    try {
      const { data } = await db.from("site_content").select("key,value").in("key", ["policy.no_show", "policy.assistance", "policy.availability"]);
      for (const r of data ?? []) {
        if (typeof r.value !== "string" || !r.value.trim()) continue;
        if (r.key === "policy.no_show") noShow = r.value; else if (r.key === "policy.assistance") assistance = r.value; else if (r.key === "policy.availability") availability = r.value;
      }
    } catch { /* defaults */ }
    rtActive = (await loadActiveRoundTripRules(db)).length > 0;
  }
  return {
    waitingText: waitingPolicyText(s.waitingIncludedMinutes, s.waitingIncrementMinutes), noShowText: noShow, assistanceText: assistance, availabilityText: availability,
    meetGreet: { enabled: s.meetGreetEnabled, chargeCents: s.meetGreetChargeCents }, roundTripDiscountActive: rtActive,
  };
}

export interface RuleRow extends RoundTripRule { categoryId: string | null }

export async function loadActiveRoundTripRules(db: SupabaseClient): Promise<RuleRow[]> {
  try {
    const { data } = await db.from("round_trip_rules").select("id,label,kind,amount,category_id,starts_at,ends_at").eq("is_active", true);
    const now = Date.now();
    return (data ?? [])
      .filter((r: Record<string, unknown>) => (!r.starts_at || new Date(String(r.starts_at)).getTime() <= now) && (!r.ends_at || new Date(String(r.ends_at)).getTime() >= now))
      .map((r: Record<string, unknown>) => ({ id: String(r.id), label: String(r.label), kind: r.kind as "flat" | "percent", amount: Number(r.amount), categoryId: (r.category_id as string | null) ?? null }));
  } catch {
    return [];
  }
}

/** Picks the rule for a vehicle category: a category-specific rule beats an all-categories one. */
export function pickRule(rules: RuleRow[], categoryId: string | null): RoundTripRule | null {
  const specific = rules.find((r) => r.categoryId && r.categoryId === categoryId);
  const any = rules.find((r) => !r.categoryId);
  const r = specific ?? any;
  return r ? { id: r.id, label: r.label, kind: r.kind, amount: r.amount } : null;
}
